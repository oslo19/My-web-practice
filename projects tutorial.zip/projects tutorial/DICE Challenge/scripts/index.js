document.getElementsByClassName("btn")[0].addEventListener("click", function() {

 

    
  });